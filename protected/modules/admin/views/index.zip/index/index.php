<div id="content" class="span10" style="margin-top: 123px !important;
margin-left: 474px !important;">
	<h1>Welcome to Ya Deal</h1>
</div>
	<div class="box-content" style="left: 30%;position: absolute;top: 100%;">
						
						<a class="quick-button span2" href="<?php echo Yii::app()->baseUrl.'/admin/UserDetail/admin';?>">
							<i class="icon-group"></i>
							<p>Users</p>
						</a>
						<a class="quick-button span2" href="<?php echo Yii::app()->baseUrl.'/admin/Offers/admin';?>">
							<i class="icon-tasks"></i>
							<p>Deals</p>
						</a>
						<a class="quick-button span2" href="<?php echo Yii::app()->baseUrl.'/admin/Payment/admin';?>">
							<i class="icon-credit-card"></i>
							<p>Payment</p>
						</a>
						</div>